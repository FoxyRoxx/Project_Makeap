from flask import Flask, request, render_template
import sqlite3  
from flask_wtf import FlaskForm
from wtforms import *
from wtforms.validators import DataRequired
from flask_sqlalchemy import SQLAlchemy
import json
import requests

# Определение формы для добавления продукта
class MyForm(FlaskForm):
    # Поле для названия продукта
    name = StringField('Name', validators=[DataRequired()]) 
    # Поле для типа проудкта
    type = SelectField('Type', choices=[('Blush'), ('Mascara'), ('Powder'), ('Eyeliner'), ('Bronzer'), ('Lipstick')]) 
    # Поле для бренда продукта
    brand = StringField('Brand')
    # Поле для рейтинга
    rating = FloatField('Rating')

app = Flask(__name__)

# Настройка соединения с базой данных
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///Makeup.db'
db = SQLAlchemy(app)

# Модель продукта для SQLAlchemy
class Product(db.Model):
    __tablename__ = 'Makeup'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80))
    type = db.Column(db.String(80))
    brand = db.Column(db.String(80))
    rating = db.Column(db.Float)

    def __init__(self, name, type, brand, rating):
        self.name = name
        self.type = type
        self.brand = brand
        self.rating = rating

# Создание соединения с базой данных  
con = sqlite3.connect('./instance/Makeup.db', check_same_thread=False)
# Создание курсора для выполнения SQL запросов  
cur = con.cursor()

# Маршрут для получения списка всех продуктов
@app.route("/makeup")
def products():
    # Выполнение SQL запроса для получения всех продуктов
    res = cur.execute("select * from Makeup")
    # Получение результата запроса
    products = res.fetchall()
    # Возвращение списка продуктов
    return render_template('makeup.html', products = products)

# Маршрут для получения информации о продукте по ID
@app.route("/price/<id>")
def product(id):
    # Выполнение SQL запроса для получения данных о продукте по ID
    res = cur.execute(f"select * from Makeup where id = ?", (id,))
    # Получение результата запроса
    product = res.fetchone()
    print(product)
    # Проверка, найден ли продукт
    if product != None:
        # Возвращение результата
        return render_template('price.html', product = product)
    else:
        # Сообщение о том, что проудкта не существует   
        return "Такого продукта нет"
#Настройка интеграции для получения цены и картинки продукта
url='https://makeup-api.herokuapp.com/api/v1/products'
response = requests.get(url).json()
request = product[1]
for i in response:
    if i['name'] == request:
        json_price = i['price']
        price = json.loads(json_price)
         #img_file =json.loads(i['image_link'])
  
# Маршрут для отображения формы нового продукта
@app.route("/form_makeup", methods=['GET', 'POST'])
def form_makeup():
    # Создание формы
    form = MyForm()
    # Проверка, была ли отправлена заполненная форма на сервер
    if form.validate_on_submit():
        # Если форма была отправлена, сохраняем данные в базу данных с помощью SQLAlchemy
        # Создаем объект класса Film
        new_product = Product(
            name=form.name.data,
            type=form.type.data,
            brand=form.brand.data,
            rating=form.rating.data
        )
        # Вставляем новый продукт в БД
        db.session.add(new_product)
        # Фиксируем изменения
        db.session.commit()
        # Возвращаем сообщение о том, что фильм добавлен
        return 'Продукт добавлен!'
    # Возвращаем форму для отображения к заполнению
    return render_template('form_makeup.html', form=form)

#Маршрут для добавления нового продукта 
@app.route("/product_add")
def product_add():
    # Получение данных о продукте из параметров запроса
    name = request.args.get('name')
    type = request.args.get('type')
    brand = request.args.get('brand')
    rating = request.args.get('rating')
    # Формирование кортежа с данными о продукте
    product_data = (name, type, brand, rating)
    # Выполнение SQL запроса для добавления продукта в базу данных
    cur.execute('INSERT INTO Makeup (name, type, brand, rating) VALUES (?, ?, ?, ?)', product_data)
    # Сохранение изменений в базе данных
    con.commit()
    # Возвращение подтверждения о добавлении продукта
    return "name = {};type = {}; brand = {}; rating = {} ".format(name, type, brand, rating) 

#Запуск приложения, если оно выполняется как главный модуль
if __name__ == '__main__':
    # Отключение проверки CSRF для WTForms
    app.config["WTF_CSRF_ENABLED"] = False  
    # Запуск приложения в режиме отладки
    app.run(debug=True)

